const people = [
    {
    img:
    "https://res.cloudinary.com/diqqf3eq2/image/upload/c_scale,w_200/v1595959121/person-1_aufeoq.jpg",
    name: "peter doe",
    job: "product manager",
    text: `I rate it a 5 star because my son loves it! He buys the Law Enforcement vehicles and the fire trucks! He also buys the train sets they sell and the workers let him see the trains moving! When he is down in the dumps we go to Amatos to cheer him up! Thank you for the kindness! I hope you become a very successful company one day!

    `,
    },
    {
    img:
    "https://res.cloudinary.com/diqqf3eq2/image/upload/c_scale,w_200/v1595959131/person-2_ipcjws.jpg",
    name: "susan doe",
    job: "developer",
    text: `Clear, concise description of how to play a game or play with a toy, calling out the learning features, e.g. builds vocabulary, inspires conversation, negotiation, critical thinking, verbal collaboration, builds auditory memory, requires naming emotions and recognizing them in others etc.`,
    },
    {
    img:
    "https://res.cloudinary.com/diqqf3eq2/image/upload/c_scale,w_200/v1595959131/person-3_rxtqvi.jpg",
    name: "emma doe",
    job: "designer",
    text: `I was a lifer at your store but circumstances dictated a move away. Relocating back I was misinformed that you were "out of business"...very sad Am elated that your"HERE!!" Needless to say that I'm back! And will be visiting the New Britain Store as soon as humanly possible.Thankyou for helping keep this senior a teenager.A lifelong dream. Thanks for the ride.`,
    },
    ];
    export default people;